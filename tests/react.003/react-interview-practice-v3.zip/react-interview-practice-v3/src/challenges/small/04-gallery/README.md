
# Small 04 — Image Gallery
Build `<Gallery images=[{src,alt}] />`.

Requirements:
- Thumbnails displayed; clicking a thumbnail sets it as the main image
- Active thumbnail has `aria-current="true"`
- Keyboard left/right changes active image

Bonus: wrap around at ends.
