
# Medium 03 — Notes App with useReducer
Implement a reducer for notes: add, toggle pin, delete, filter by query.

State shape:
```
{ items: Array<{id,text,pinned:boolean}>, q: string }
```
