
# Medium 02 — Reorderable List
Render a list of items with Up/Down buttons to reorder.

Requirements:
- Clicking Up/Down moves items
- Top item Up and bottom item Down are disabled
- `onChange(order)` emits new order
