
# Small 02 — Accessible Dropdown
Build `<Dropdown items=[{id,label}] onSelect(id) />`.

Requirements:
- Click to open/close list
- Keyboard: ArrowDown/ArrowUp to move focus, Enter to select, Escape to close
- Close when clicking outside

Bonus: loop focus from last to first.
