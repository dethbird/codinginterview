# React Interview Practice — v3.1 (Stable Harness)

Same harness as v3 (deterministic). Differences:
- **Small #01 (useCountdown)** now has TODOs; tests start red.
- **Small #06 (Toggle List)** now has TODOs; tests start red.

## Quickstart
```bash
npm i
npm run dev -- --host 0.0.0.0
npm run test:watch
```
