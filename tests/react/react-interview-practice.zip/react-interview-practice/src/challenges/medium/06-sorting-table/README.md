# Sorting Table

Render a table of users with sortable columns (name, email, age).
Acceptance criteria:
- Clicking a header toggles sort asc/desc by that key.
- Visual indicator of sort direction.

