# Infinite Scroll

Build a list that fetches pages as you scroll near the bottom.
Acceptance criteria:
- Use IntersectionObserver to load next page.
- Show loading indicator. Stop when no more items.
- (Use a fake fetch that resolves arrays of items.) 

