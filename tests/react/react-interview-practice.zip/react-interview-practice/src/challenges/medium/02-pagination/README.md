# Pagination Component

Build <Pagination total={95} perPage={10} onChange(page) /> controlled by parent.
Acceptance criteria:
- Renders numbered buttons for pages and Prev/Next.
- Disables Prev on first page and Next on last.
- Calls onChange with the new page number (1-based).

