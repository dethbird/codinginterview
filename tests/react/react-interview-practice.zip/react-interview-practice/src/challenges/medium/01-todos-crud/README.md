# CRUD Todos with Persist

Build a Todo app with add, toggle, and delete. Persist in localStorage.
Acceptance criteria:
- Input adds todo with Enter (trim, ignore empty).
- List shows items with checkbox to toggle completed.
- Each item has a delete button.
- Persist across reloads.

