# Counter with Step

Build a <Counter step={5} initial={0}/> component with + / – / Reset buttons.
Requirements:
- Clicking + or – adjusts by `step` (default 1).
- Reset returns to `initial` (default 0).
- Bonus: persist to localStorage under key `counter:value`.

