# Tabs

Build <Tabs tabs={[{label, content}]} /> showing active tab content.
Requirements:
- Click label to activate.
- First tab active by default.

