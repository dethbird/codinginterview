# Theme Toggle

Build <ThemeToggle/> that switches dark/light and persists selection.
Requirements:
- Clicking button toggles between "light" and "dark".
- Apply theme as data attribute on documentElement: data-theme="dark|light".
- Persist in localStorage 'theme'.

