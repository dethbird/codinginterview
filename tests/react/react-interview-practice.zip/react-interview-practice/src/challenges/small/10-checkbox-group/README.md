# Checkbox Group with Select All

Build checkboxes with a "Select All" master toggle.
Requirements:
- Master checks all; unchecking an item unchecks master.

