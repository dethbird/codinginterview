# useLocalStorage Hook

Write useLocalStorage(key, initial) that returns [value, setValue].
Requirements:
- JSON serialize/parse.
- Update localStorage on change.

