# Textarea Character Counter

Build <TextareaWithCount max={200}/> showing "N / 200".
Requirements:
- Controlled textarea.
- When over max, count turns red and submit is disabled.

