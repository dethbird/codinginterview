# Stopwatch

Build a simple stopwatch with Start / Pause / Reset showing elapsed seconds.
Requirements:
- Use setInterval, cleanup on unmount.
- Accurate pause/resume (don’t drift).

