# Filter List

Build <FilterList items={['apple','banana','pear']}/> with a search box.
Requirements:
- Typing filters items case-insensitively.

