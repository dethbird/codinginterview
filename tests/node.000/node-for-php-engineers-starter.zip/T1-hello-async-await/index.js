'use strict';

function sleep(ms) {
  // TODO: return new Promise(resolve => setTimeout(resolve, Math.max(0, ms)));
}

(async () => {
  // TODO: for (let i=1;i<=5;i++){ await sleep(200); console.log('tick', i); }
})();
