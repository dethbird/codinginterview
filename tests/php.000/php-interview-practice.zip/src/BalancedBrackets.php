<?php
declare(strict_types=1);

namespace App;

final class BalancedBrackets
{
    /**
     * Return true if brackets (), {}, [] are balanced and properly nested.
     */
    public static function isValid(string $s): bool
    {
        // TODO: stack-based check
        throw new \RuntimeException('TODO');
    }
}
