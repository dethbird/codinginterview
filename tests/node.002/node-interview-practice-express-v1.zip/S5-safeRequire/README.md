# S5 — `safeRequire(path)`

Goal: Sync load JSON or JS without throwing; return `{ ok:true, value }` or `{ ok:false, error }`.
