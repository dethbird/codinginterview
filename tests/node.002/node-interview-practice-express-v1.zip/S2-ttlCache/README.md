# S2 — `ttlCache()`

Goal: In-memory TTL cache with `get/set/has/delete`, `size`, optional background sweeper, and `close()`.
