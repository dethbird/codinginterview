# Medium 01 — Form Wizard
Build a 3-step wizard (Account → Profile → Confirm).

Requirements:
- Next/Back navigation with validation per step
- Aggregate state across steps
- Submit shows "Submitted!" with final payload

Bonus: disable Next when current step invalid.
