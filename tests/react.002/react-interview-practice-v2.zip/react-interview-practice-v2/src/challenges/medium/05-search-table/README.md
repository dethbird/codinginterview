# Medium 05 — Searchable + Sortable Table
Given rows = [{name, email, age}], build a table with:
- Search box filters by name/email
- Clickable headers sort asc/desc
- Show sort indicator on active column
