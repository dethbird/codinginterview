# Small 06 — Toggleable List
Given items, render checkboxes. "Select All" toggles all. Show a summary: "X of N selected".

Requirements:
- Controlled checkboxes in array state
- Master checkbox reflects indeterminate state
- Summary updates correctly
