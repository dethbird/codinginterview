import * as React from 'react';
import { useFlag } from './FlagsProvider';
import type { FlagKey, FlagValue } from './registry';

export type FeatureGateProps<K extends FlagKey> = {
  flag: K;
  when?: (value: FlagValue<K>) => boolean;
  children: React.ReactNode;
  fallback?: React.ReactNode;
  onExpose?: (key: K, value: FlagValue<K>) => void;
};

export function FeatureGate<K extends FlagKey>({
  flag,
  when,
  children,
  fallback = null,
  onExpose,
}: FeatureGateProps<K>) {
  const value = useFlag(flag);
  const enabled = when ? when(value) : Boolean(value);

  // Fire exposure once per mount for this flag/value pair
  const firedRef = React.useRef(false);
  React.useEffect(() => {
    if (!firedRef.current) {
      onExpose?.(flag, value);
      firedRef.current = true;
    }
  }, [flag, value, onExpose]);

  return <>{enabled ? children : fallback}</>;
}
