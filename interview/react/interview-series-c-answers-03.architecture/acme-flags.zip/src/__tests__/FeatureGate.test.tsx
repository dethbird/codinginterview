import { render, screen } from '@testing-library/react';
import React from 'react';
import { FlagsProvider } from '../FlagsProvider';
import { FeatureGate } from '../FeatureGate';

describe('FeatureGate', () => {
  it('renders fallback when flag off', () => {
    render(
      <FlagsProvider initialFlags={{ newCheckout: false }}>
        <FeatureGate flag="newCheckout" fallback={<span>legacy</span>}>
          <span>new</span>
        </FeatureGate>
      </FlagsProvider>
    );
    expect(screen.getByText('legacy')).toBeInTheDocument();
  });

  it('renders primary when flag on', () => {
    render(
      <FlagsProvider initialFlags={{ newCheckout: true }}>
        <FeatureGate flag="newCheckout" fallback={<span>legacy</span>}>
          <span>new</span>
        </FeatureGate>
      </FlagsProvider>
    );
    expect(screen.getByText('new')).toBeInTheDocument();
  });
});
