// Central registry for feature flags.
// Co-locate types with registry so consumers get strong typing.
export const flagRegistry = {
  newCheckout: {
    type: 'boolean' as const,
    default: false,
    description: 'Enable new checkout flow',
  },
  searchBackend: {
    type: 'string' as const,
    default: 'v1',
    variants: ['v1', 'v2'] as const,
    description: 'Backend variant for search results',
  },
  resultsPageSize: {
    type: 'number' as const,
    default: 20,
    min: 5,
    max: 100,
    description: 'Number of results per page',
  },
};

export type FlagKey = keyof typeof flagRegistry;

export type FlagValue<K extends FlagKey> =
  typeof flagRegistry[K] extends { type: 'boolean' } ? boolean :
  typeof flagRegistry[K] extends { type: 'string', variants: readonly (infer V)[] } ? V :
  number;

export type FlagBag = { [K in FlagKey]: FlagValue<K> };
