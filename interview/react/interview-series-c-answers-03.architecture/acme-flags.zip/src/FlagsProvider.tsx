import * as React from 'react';
import { flagRegistry, type FlagKey, type FlagValue, type FlagBag } from './registry';

export type FlagsContextType = {
  flags: FlagBag;
  get<K extends FlagKey>(key: K): FlagValue<K>;
  set<K extends FlagKey>(key: K, value: FlagValue<K>): void;
};

const FlagsContext = React.createContext<FlagsContextType | null>(null);

export type FlagsProviderProps = {
  initialFlags?: Partial<FlagBag>;
  children: React.ReactNode;
};

function fillWithDefaults(initial?: Partial<FlagBag>): FlagBag {
  const out = {} as FlagBag;
  (Object.keys(flagRegistry) as FlagKey[]).forEach((k) => {
    // @ts-expect-error: simplifying inference
    out[k] = (initial?.[k] ?? flagRegistry[k].default) as any;
  });
  return out;
}

export function FlagsProvider({ initialFlags, children }: FlagsProviderProps) {
  const [flags, setFlags] = React.useState<FlagBag>(() => fillWithDefaults(initialFlags));

  const ctx = React.useMemo<FlagsContextType>(() => ({
    flags,
    get: (k) => flags[k],
    set: (k, v) => setFlags((prev) => ({ ...prev, [k]: v })),
  }), [flags]);

  return <FlagsContext.Provider value={ctx}>{children}</FlagsContext.Provider>;
}

export function useFlags(): FlagsContextType {
  const ctx = React.useContext(FlagsContext);
  if (!ctx) throw new Error('useFlags must be used within FlagsProvider');
  return ctx;
}

export function useFlag<K extends FlagKey>(key: K): FlagValue<K> {
  const { get } = useFlags();
  return get(key);
}

/** Optional: read overrides from URL or localStorage for E2E/testing */
export function parseFlagOverrides(search = typeof window !== 'undefined' ? window.location.search : ''): Partial<FlagBag> {
  try {
    const params = new URLSearchParams(search);
    const raw = params.get('flags');
    if (!raw) return {};
    const pairs = raw.split(',').map(s => s.trim()).filter(Boolean);
    const out: Record<string, any> = {};
    for (const p of pairs) {
      const [k, v] = p.split(':').map(s => s.trim());
      if (!k) continue;
      if (!(k in flagRegistry)) continue;
      const def = (flagRegistry as any)[k];
      if (def.type === 'boolean') out[k] = v === 'true';
      else if (def.type === 'number') out[k] = Number(v);
      else out[k] = v;
    }
    return out as Partial<FlagBag>;
  } catch {
    return {};
  }
}
