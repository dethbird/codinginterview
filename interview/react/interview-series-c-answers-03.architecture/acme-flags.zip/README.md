# @acme/flags

A tiny, type-safe feature flag system for React apps.

## Install
```bash
pnpm add @acme/flags
# or npm/yarn
```

## Define flags (types live with the registry)
```ts
// src/flags/registry.ts
export const flagRegistry = {
  newCheckout: { type: 'boolean' as const, default: false },
  searchBackend: { type: 'string' as const, default: 'v1', variants: ['v1','v2'] as const },
  resultsPageSize: { type: 'number' as const, default: 20 },
};
export type FlagKey = keyof typeof flagRegistry;
export type FlagValue<K extends FlagKey> =
  typeof flagRegistry[K] extends { type: 'boolean' } ? boolean :
  typeof flagRegistry[K] extends { type: 'string', variants: readonly (infer V)[] } ? V :
  number;
```

## Provide flags
```tsx
import { FlagsProvider } from '@acme/flags';
import { parseFlagOverrides } from '@acme/flags';

const overrides = parseFlagOverrides(); // ?flags=newCheckout:true,searchBackend:v2

root.render(
  <FlagsProvider initialFlags={overrides}>
    <App />
  </FlagsProvider>
);
```

## Gate components
```tsx
import { FeatureGate } from '@acme/flags';

<FeatureGate flag="newCheckout" fallback={<LegacyCheckout />}>
  <NewCheckout />
</FeatureGate>
```

## Read a flag
```tsx
import { useFlag } from '@acme/flags';
const pageSize = useFlag('resultsPageSize'); // typed as number
```

## Build & test
```bash
pnpm run build
pnpm run test
```
